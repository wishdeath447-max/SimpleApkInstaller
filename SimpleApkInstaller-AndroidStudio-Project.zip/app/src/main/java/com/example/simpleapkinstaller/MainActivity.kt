package com.example.simpleapkinstaller

import android.app.Activity
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.PackageInstaller
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import java.io.IOException

class MainActivity : AppCompatActivity() {
    private lateinit var progress: ProgressBar
    private lateinit var status: TextView
    private lateinit var count: TextView
    private lateinit var list: TextView
    private lateinit var installButton: Button
    private val selected = mutableListOf<Uri>()
    private var queueIndex = 0

    private val picker = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        selected.clear()
        selected.addAll(uris.filter { it.toString().endsWith(".apk", ignoreCase = true) ||
            contentResolver.getType(it) == "application/vnd.android.package-archive" })
        contentResolver.takePersistableUriPermission(
            selected.firstOrNull() ?: return@registerForActivityResult,
            Intent.FLAG_GRANT_READ_URI_PERMISSION
        )
        renderSelection()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (intent.hasExtra(InstallStatusReceiver.EXTRA_STATUS)) {
            onInstallResult(
                -1,
                intent.getIntExtra(InstallStatusReceiver.EXTRA_STATUS, PackageInstaller.STATUS_FAILURE),
                intent.getStringExtra(InstallStatusReceiver.EXTRA_MESSAGE)
            )
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        progress = findViewById(R.id.progressBar)
        status = findViewById(R.id.statusText)
        count = findViewById(R.id.countText)
        list = findViewById(R.id.fileList)
        installButton = findViewById(R.id.installButton)

        findViewById<Button>(R.id.chooseButton).setOnClickListener {
            picker.launch(arrayOf("application/vnd.android.package-archive", "*/*"))
        }
        installButton.setOnClickListener {
            if (!packageManager.canRequestPackageInstalls()) {
                startActivity(Intent(android.provider.Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                    Uri.parse("package:$packageName")))
                status.text = "Allow installs from this app, then tap Install again."
            } else {
                queueIndex = 0
                installNext()
            }
        }
    }

    private fun renderSelection() {
        count.text = "${selected.size} APK file(s) selected"
        list.text = selected.mapIndexed { i, uri ->
            "${i + 1}. ${uri.lastPathSegment?.substringAfterLast('/') ?: "APK file"}"
        }.joinToString("\n")
        installButton.isEnabled = selected.isNotEmpty()
        status.text = if (selected.isEmpty()) "No APK files selected" else "Ready to install"
    }

    private fun installNext() {
        if (queueIndex >= selected.size) {
            status.text = "Queue finished."
            progress.visibility = View.GONE
            installButton.isEnabled = true
            return
        }
        val uri = selected[queueIndex]
        val displayName = uri.lastPathSegment?.substringAfterLast('/') ?: "APK ${queueIndex + 1}"
        status.text = "Preparing ${queueIndex + 1}/${selected.size}: $displayName"
        progress.visibility = View.VISIBLE
        progress.progress = 0
        installButton.isEnabled = false

        Thread {
            var sessionId = -1
            try {
                val params = PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL)
                sessionId = packageManager.packageInstaller.createSession(params)
                packageManager.packageInstaller.openSession(sessionId).use { session ->
                    contentResolver.openInputStream(uri).use { input ->
                        if (input == null) throw IOException("Cannot open selected APK")
                        session.openWrite("base.apk", 0, -1).use { output ->
                            val buffer = ByteArray(64 * 1024)
                            var total = 0L
                            val size = contentResolver.openFileDescriptor(uri, "r")?.use { it.statSize } ?: -1L
                            while (true) {
                                val n = input.read(buffer)
                                if (n < 0) break
                                output.write(buffer, 0, n)
                                total += n
                                if (size > 0) {
                                    val pct = ((total * 100) / size).toInt().coerceIn(0, 100)
                                    runOnUiThread { progress.progress = pct }
                                    session.setProgress(pct / 100f)
                                }
                            }
                            session.fsync(output)
                        }
                    }
                    val callback = Intent(this, InstallStatusReceiver::class.java).apply {
                        action = InstallStatusReceiver.ACTION
                        putExtra(InstallStatusReceiver.EXTRA_SESSION_ID, sessionId)
                    }
                    val pending = PendingIntent.getBroadcast(
                        this, sessionId, callback,
                        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
                    )
                    session.commit(pending.intentSender)
                }
                runOnUiThread { status.text = "Waiting for Android installation confirmation…" }
            } catch (e: Exception) {
                if (sessionId >= 0) packageManager.packageInstaller.abandonSession(sessionId)
                runOnUiThread {
                    status.text = "Failed to prepare $displayName: ${e.message ?: "Unknown error"}"
                    progress.visibility = View.GONE
                    installButton.isEnabled = true
                }
            }
        }.start()
    }

    fun onInstallResult(sessionId: Int, statusCode: Int, message: String?) {
        runOnUiThread {
            when (statusCode) {
                PackageInstaller.STATUS_SUCCESS -> {
                    status.text = "Installed ${queueIndex + 1}/${selected.size}"
                    queueIndex++
                    installNext()
                }
                PackageInstaller.STATUS_PENDING_USER_ACTION -> {
                    status.text = "Confirm installation in the Android system dialog."
                }
                else -> {
                    status.text = "Installation failed: ${message ?: "Error code $statusCode"}"
                    queueIndex++
                    installNext()
                }
            }
        }
    }
}
