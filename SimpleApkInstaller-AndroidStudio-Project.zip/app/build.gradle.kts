plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.example.simpleapkinstaller"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.example.simpleapkinstaller"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}

dependencies {\n    implementation("androidx.appcompat:appcompat:1.7.0")\n    implementation("androidx.activity:activity-ktx:1.9.3")\n}\n