# Simple APK Installer

A small Kotlin Android Studio starter project with a simple UI, multi-file APK selection, a preparation progress bar, and sequential Android PackageInstaller sessions.

## Build
1. Open this folder in Android Studio (Hedgehog or newer).
2. Let Gradle sync.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).

## Important Android behavior
- Android's system package installer owns the actual installation and asks the user to confirm each APK.
- The progress bar measures copying the selected APK into a PackageInstaller session. Android controls the final install UI and does not expose a universal byte-by-byte installation percentage to third-party apps.
- Allow "Install unknown apps" for this app when Android prompts.
- Use trusted APK files only.

## Notes
This is a starter source project, not a precompiled APK. Test on a physical device. The sample intentionally avoids silent installation or bypassing Android security prompts.
